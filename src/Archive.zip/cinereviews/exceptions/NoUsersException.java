package cinereviews.exceptions;

public class NoUsersException extends Exception {
    public NoUsersException() {}
}
