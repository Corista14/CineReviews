package user;

/**
 * Interface for the audience type user
 * @author Filipe Corista / João Rodrigues
 */
public interface AudienceUser extends OrdinaryUser {
}
