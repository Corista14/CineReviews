package user.exceptions;

public class NotAnAdminException extends Exception {

    public NotAnAdminException() {}
}
