package user.exceptions;

public class UnknownUserException extends Exception {
    public UnknownUserException() {}
}
