package user.exceptions;

public class WrongPasswordException extends Exception {

    public WrongPasswordException() {}
}
