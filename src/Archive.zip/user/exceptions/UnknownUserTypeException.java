package user.exceptions;

public class UnknownUserTypeException extends RuntimeException {

    public UnknownUserTypeException() {}

}
