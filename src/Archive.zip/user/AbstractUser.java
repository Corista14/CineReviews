package user;

/**
 * Abstract class for the user
 * @author Filipe Corista / João Rodrigues
 */
public abstract class AbstractUser implements User {
}
