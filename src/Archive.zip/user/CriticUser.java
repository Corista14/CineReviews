package user;

/**
 * Interface for the critic type user
 * @author Filipe Corista / João Rodrigues
 */
public interface CriticUser extends OrdinaryUser {

}
