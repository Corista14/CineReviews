package show.exceptions;

public class ShowAlreadyExistsException extends Exception {

    public ShowAlreadyExistsException() {}
}
