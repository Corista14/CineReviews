package show;

public interface Movie extends Show {

    int getDuration();
}
