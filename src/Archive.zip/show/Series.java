package show;

public interface Series extends Show {

    int getNumberOfSeasons();
}
