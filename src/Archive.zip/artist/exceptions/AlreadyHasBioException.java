package artist.exceptions;

public class AlreadyHasBioException extends  Exception{
    public AlreadyHasBioException(){
        super();
    }
}
